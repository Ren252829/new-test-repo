﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtJudul = New System.Windows.Forms.TextBox()
        Me.txtGenre = New System.Windows.Forms.TextBox()
        Me.btnTambah = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnLihat = New System.Windows.Forms.Button()
        Me.lvBuku = New System.Windows.Forms.ListView()
        Me.btnKeluar = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtJudul
        '
        Me.txtJudul.Location = New System.Drawing.Point(179, 90)
        Me.txtJudul.Margin = New System.Windows.Forms.Padding(5)
        Me.txtJudul.Name = "txtJudul"
        Me.txtJudul.Size = New System.Drawing.Size(266, 39)
        Me.txtJudul.TabIndex = 0
        '
        'txtGenre
        '
        Me.txtGenre.Location = New System.Drawing.Point(179, 161)
        Me.txtGenre.Margin = New System.Windows.Forms.Padding(5)
        Me.txtGenre.Name = "txtGenre"
        Me.txtGenre.Size = New System.Drawing.Size(281, 39)
        Me.txtGenre.TabIndex = 1
        '
        'btnTambah
        '
        Me.btnTambah.Location = New System.Drawing.Point(195, 238)
        Me.btnTambah.Margin = New System.Windows.Forms.Padding(5)
        Me.btnTambah.Name = "btnTambah"
        Me.btnTambah.Size = New System.Drawing.Size(206, 79)
        Me.btnTambah.TabIndex = 3
        Me.btnTambah.Text = "Tambah Buku"
        Me.btnTambah.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 98)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 27)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Judul Buku"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(23, 173)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label2.Size = New System.Drawing.Size(72, 27)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Genre"
        '
        'btnLihat
        '
        Me.btnLihat.Location = New System.Drawing.Point(179, 342)
        Me.btnLihat.Margin = New System.Windows.Forms.Padding(5)
        Me.btnLihat.Name = "btnLihat"
        Me.btnLihat.Size = New System.Drawing.Size(248, 53)
        Me.btnLihat.TabIndex = 9
        Me.btnLihat.Text = "Lihat Daftar"
        Me.btnLihat.UseVisualStyleBackColor = True
        '
        'lvBuku
        '
        Me.lvBuku.GridLines = True
        Me.lvBuku.Location = New System.Drawing.Point(892, 78)
        Me.lvBuku.Margin = New System.Windows.Forms.Padding(5)
        Me.lvBuku.Name = "lvBuku"
        Me.lvBuku.Size = New System.Drawing.Size(317, 317)
        Me.lvBuku.TabIndex = 11
        Me.lvBuku.UseCompatibleStateImageBehavior = False
        Me.lvBuku.View = System.Windows.Forms.View.Details
        '
        'btnKeluar
        '
        Me.btnKeluar.Location = New System.Drawing.Point(179, 426)
        Me.btnKeluar.Margin = New System.Windows.Forms.Padding(5)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(252, 89)
        Me.btnKeluar.TabIndex = 12
        Me.btnKeluar.Text = "Keluar dari Program"
        Me.btnKeluar.UseVisualStyleBackColor = True
        '
        'btnHapus
        '
        Me.btnHapus.Location = New System.Drawing.Point(984, 426)
        Me.btnHapus.Margin = New System.Windows.Forms.Padding(5)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(113, 39)
        Me.btnHapus.TabIndex = 10
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1924, 910)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.lvBuku)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.btnLihat)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnTambah)
        Me.Controls.Add(Me.txtGenre)
        Me.Controls.Add(Me.txtJudul)
        Me.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtJudul As System.Windows.Forms.TextBox
    Friend WithEvents txtGenre As System.Windows.Forms.TextBox
    Friend WithEvents btnTambah As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnLihat As System.Windows.Forms.Button
    Friend WithEvents lvBuku As System.Windows.Forms.ListView
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents btnHapus As System.Windows.Forms.Button

End Class
