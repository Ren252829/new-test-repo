﻿Module Module1
    Public Structure Buku
        Public Judul As String
        Public Genre As String
    End Structure

    Public DataBuku() As Buku
    Public JumlahBuku As Integer = 0
End Module
