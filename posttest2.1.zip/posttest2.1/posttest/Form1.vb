﻿Public Class Form1
    Private Sub ButtonTambah_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        If txtJudul.Text <> "" AndAlso txtGenre.Text <> "" Then
            Dim bukuBaru As Buku
            bukuBaru.Judul = txtJudul.Text
            bukuBaru.Genre = txtGenre.Text

            TambahBuku(bukuBaru)
            TampilkanDaftarBuku()
            txtJudul.Clear()
            txtGenre.Clear()
        End If
    End Sub

    Private Sub ButtonHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        If lvBuku.SelectedItems.Count > 0 Then
            Dim index As Integer = lvBuku.SelectedIndices(0)
            HapusBuku(index)
            TampilkanDaftarBuku()
        End If
    End Sub

    Private Sub TambahBuku(ByVal buku As Buku)
        ReDim Preserve DataBuku(JumlahBuku)
        DataBuku(JumlahBuku) = buku
        JumlahBuku += 1
    End Sub

    Private Sub HapusBuku(ByVal index As Integer)
        If index >= 0 AndAlso index < JumlahBuku Then
            For i As Integer = index To JumlahBuku - 2
                DataBuku(i) = DataBuku(i + 1)
            Next
            JumlahBuku -= 1
            ReDim Preserve DataBuku(JumlahBuku)
        End If
    End Sub

    Private Sub TampilkanDaftarBuku()
        lvBuku.Items.Clear()

        For i As Integer = 0 To JumlahBuku - 1
            Dim item As New ListViewItem(DataBuku(i).Judul)
            item.SubItems.Add(DataBuku(i).Genre)
            lvBuku.Items.Add(item)
        Next
    End Sub


    Private Sub ButtonLihatDaftar_Click(sender As Object, e As EventArgs) Handles btnLihat.Click
        Form2.Show()
    End Sub

    Private Sub ButtonKeluar_Click(sender As Object, e As EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lvBuku.Columns.Add("Judul", 120)
        lvBuku.Columns.Add("Genre", 120)

    End Sub
End Class
